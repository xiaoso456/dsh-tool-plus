hello from inside zip member inner/docs/readme.txt (written by tool-plus write)
