# tar member note

written by tool-plus write into a .tar.gz archive member.
